Thank you for installing Varsity's Wonderful Shitshow of Tools (VWST for short :] )


This toolset includes:

- Bluecoat Trasher (Brilliant for stopping that pesky app that keeps ruining your browsing experience!!)

- Symantec CleanWipe (Gets rid of Symantec Endpoint Protection, the thing that stops you from installing Discord and other lovley apps.)

- Psiphon (Sick and tired of school proxies? Fuck that shit have Psiphon it will stop school proxies from fucking with
your browsing, however the network will most likely be slow becuz its a VPN)

- And more to come!


Make sure to keep your application list updated by emailing Copy-Copter@hotmail.com or contacting your broker, make sure you have a legit
version by checking out VarsitysWonderfulShitshowofTools.github.io which comes with a full list of feature and legit application 
names etc, also that site has the files too!

Enjoy, and oh, spread this around the entire school becuz fuck tha police!

Love, Copy-Copter


P.S make sure your teachers or the IT don't find this on your laptop or you're probably gonna get expelled!

I would put my crush confession here but that sounds vsco LMFAO
